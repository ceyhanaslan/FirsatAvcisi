package com.firsatavcisi.app

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView

private data class MarketSource(
    val name: String,
    val url: String,
    val description: String
)

private val sources = listOf(
    MarketSource(
        "BİM",
        "https://www.bim.com.tr/",
        "BİM'in resmî aktüel ürün ve indirim afişleri"
    ),
    MarketSource(
        "ŞOK",
        "https://kurumsal.sokmarket.com.tr/tr/firsatlar",
        "ŞOK'un resmî haftalık ve hafta sonu fırsat katalogları"
    ),
    MarketSource(
        "A101",
        "https://www.a101.com.tr/aldin-aldin",
        "A101'in resmî Aldın Aldın ürün ve kampanya sayfası"
    )
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FirsatAvcisiOfficialSources() }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FirsatAvcisiOfficialSources() {
    var selected by remember { mutableIntStateOf(0) }
    var pageLoading by remember { mutableStateOf(true) }
    var webView by remember { mutableStateOf<WebView?>(null) }
    val source = sources[selected]

    BackHandler(enabled = webView?.canGoBack() == true) {
        webView?.goBack()
    }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("Fırsat Avcısı")
                            Text("Resmî market kampanyaları", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding)
            ) {
                TabRow(selectedTabIndex = selected) {
                    sources.forEachIndexed { index, market ->
                        Tab(
                            selected = selected == index,
                            onClick = { selected = index; pageLoading = true },
                            text = { Text(market.name) }
                        )
                    }
                }

                Card(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Text(source.description, style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Kaynak: ${source.url}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedButton(
                                onClick = { webView?.reload(); pageLoading = true },
                                modifier = Modifier.weight(1f)
                            ) { Text("Yenile") }
                            Button(
                                onClick = { webView?.loadUrl(source.url); pageLoading = true },
                                modifier = Modifier.weight(1f)
                            ) { Text("Resmî sayfayı aç") }
                        }
                    }
                }

                if (pageLoading) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(8.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator()
                        Text("  Resmî kampanyalar yükleniyor…")
                    }
                }

                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { context ->
                        WebView(context).apply {
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            settings.loadsImagesAutomatically = true
                            webViewClient = object : WebViewClient() {
                                override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                                    pageLoading = true
                                }
                                override fun onPageFinished(view: WebView?, url: String?) {
                                    pageLoading = false
                                }
                            }
                            webChromeClient = WebChromeClient()
                            loadUrl(source.url)
                            webView = this
                        }
                    },
                    update = { view ->
                        if (view.tag != source.url) {
                            view.tag = source.url
                            view.loadUrl(source.url)
                        }
                        webView = view
                    }
                )
            }
        }
    }
}
