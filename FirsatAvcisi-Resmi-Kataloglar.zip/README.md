# Fırsat Avcısı — Resmî Kampanya Kaynakları (Android)

Bu sürüm demo ürün/fiyat kartlarını kaldırır ve marketlerin resmî kampanya sayfalarını uygulama içinde açar.

## Bağlı resmî kaynaklar
- BİM: https://www.bim.com.tr/
- ŞOK: https://kurumsal.sokmarket.com.tr/tr/firsatlar
- A101: https://www.a101.com.tr/aldin-aldin

## Önemli kapsam notu
Bu sürüm gerçek ve güncel resmî sayfaları uygulama içinde gösterir. Henüz ürünleri otomatik ayrıştıran birleşik ürün akışı, fiyat geçmişi, stok takibi veya arka plan fiyat alarmı sunmaz. Bu özellikler için market kaynaklarının teknik olarak ayrıştırılması, veri doğrulama ve sürekli çalışan bir backend gerekir. Katalog fiyatı mağaza stoğu/fiyat garantisi değildir.

## Derleme
JDK 17+, Android SDK 35, Gradle 8.9 veya üzeri gerekir.
Codemagic'te ZIP'i açıp Gradle 8.9 ile `:app:assembleDebug` çalıştırabilirsiniz.
