package com.firsatavcisi.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import java.util.Locale

private enum class Market(val title: String) { ALL("Tüm marketler"), BIM("BİM"), SOK("ŞOK"), A101("A101") }
private enum class Category(val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    ALL("Tüm kategoriler", Icons.Default.Apps), HOME("Ev ve yaşam", Icons.Default.Home),
    SPORT("Spor ve fitness", Icons.Default.FitnessCenter), FOOD("Gıda", Icons.Default.Restaurant)
}
private data class Deal(
    val id: Int, val name: String, val market: String, val category: Category,
    val price: Double, val oldPrice: Double, val detail: String
) {
    val discount: Int get() = if (oldPrice > price && oldPrice > 0) (((oldPrice-price)/oldPrice)*100).toInt() else 0
}
private val demoDeals = listOf(
    Deal(1,"Darbeli şarjlı matkap","BİM",Category.HOME,1499.0,1999.0,"Ev ve yaşam"),
    Deal(2,"Ayarlanabilir dambıl seti","ŞOK",Category.SPORT,899.0,1199.0,"Spor ve fitness"),
    Deal(3,"Zeytinyağı 1 L","A101",Category.FOOD,249.90,299.90,"Gıda"),
    Deal(4,"Katlanır kamp sandalyesi","BİM",Category.HOME,399.0,499.0,"Ev ve yaşam"),
    Deal(5,"Fitness matı","A101",Category.SPORT,179.0,229.0,"Spor ve fitness"),
    Deal(6,"Filtre kahve 250 g","ŞOK",Category.FOOD,119.90,139.90,"Gıda")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel(this)
        setContent { FirsatApp() }
    }
}
private fun createNotificationChannel(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val channel = NotificationChannel("deals", "Yeni fırsatlar", NotificationManager.IMPORTANCE_DEFAULT)
        context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }
}
private fun sendTestNotification(context: Context) {
    val n = NotificationCompat.Builder(context, "deals")
        .setSmallIcon(android.R.drawable.ic_dialog_info)
        .setContentTitle("Fırsat Avcısı")
        .setContentText("Bildirimler hazır. Yeni fırsatlar burada duyurulacak.")
        .setPriority(NotificationCompat.PRIORITY_DEFAULT).build()
    if (Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
        NotificationManagerCompat.from(context).notify(1001, n)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FirsatApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("firsat_prefs", Context.MODE_PRIVATE) }
    var market by remember { mutableStateOf(Market.ALL) }
    var category by remember { mutableStateOf(Category.ALL) }
    var query by remember { mutableStateOf("") }
    var favoritesOnly by remember { mutableStateOf(false) }
    var favorites by remember { mutableStateOf(prefs.getStringSet("favorites", emptySet())?.toSet() ?: emptySet()) }
    var alertsOn by remember { mutableStateOf(prefs.getBoolean("alerts", true)) }
    var showInfo by remember { mutableStateOf(false) }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) sendTestNotification(context)
    }
    val filtered = remember(market, category, query, favoritesOnly, favorites) {
        demoDeals.filter {
            (market == Market.ALL || it.market == market.title) &&
            (category == Category.ALL || it.category == category) &&
            it.name.contains(query, ignoreCase = true) &&
            (!favoritesOnly || favorites.contains(it.id.toString()))
        }.sortedByDescending { it.discount }
    }
    MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF167A45), secondary = Color(0xFFEA6A35))) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Column { Text("Fırsat Avcısı", fontWeight = FontWeight.Bold); Text("BİM · ŞOK · A101", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) } },
                    actions = {
                        IconButton(onClick = { favoritesOnly = !favoritesOnly }) {
                            Icon(if (favoritesOnly) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Favoriler")
                        }
                        IconButton(onClick = { showInfo = true }) { Icon(Icons.Default.Info, "Bilgi") }
                    }
                )
            }
        ) { padding ->
            Column(Modifier.padding(padding).fillMaxSize().background(Color(0xFFF7F8F6))) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Market.values().filter { it != Market.ALL }.forEach { m ->
                        FilterChip(selected = market == m, onClick = { market = if (market == m) Market.ALL else m }, label = { Text(m.title) })
                    }
                }
                OutlinedTextField(
                    value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    placeholder = { Text("Ürün ara…") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true
                )
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Category.values().forEach { c ->
                        if (c == Category.ALL) return@forEach
                        FilterChip(selected = category == c, onClick = { category = if (category == c) Category.ALL else c },
                            label = { Text(when(c) { Category.HOME -> "Ev"; Category.SPORT -> "Spor"; else -> "Gıda" }) })
                    }
                }
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(if (favoritesOnly) "Favorilerin" else "Bugünün fırsatları", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("${filtered.size} ürün · İndirim oranına göre sıralı", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Alarm", style = MaterialTheme.typography.labelMedium)
                        Switch(checked = alertsOn, onCheckedChange = {
                            alertsOn = it; prefs.edit().putBoolean("alerts", it).apply()
                            if (it && Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                                permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            else if (it) sendTestNotification(context)
                        })
                    }
                }
                LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(filtered, key = { it.id }) { deal ->
                        DealCard(deal, favorites.contains(deal.id.toString())) {
                            val next = favorites.toMutableSet()
                            if (!next.add(deal.id.toString())) next.remove(deal.id.toString())
                            favorites = next
                            prefs.edit().putStringSet("favorites", next).apply()
                        }
                    }
                    if (filtered.isEmpty()) item { Text("Bu filtrelerde ürün bulunamadı.", Modifier.padding(24.dp), color = Color.Gray) }
                    item { Text("Not: Ürün ve fiyatlar demo verisidir; gerçek market kampanyaları henüz bağlı değildir.", style = MaterialTheme.typography.bodySmall, color = Color.Gray) }
                }
            }
        }
        if (showInfo) AlertDialog(onDismissRequest = { showInfo = false }, confirmButton = { TextButton(onClick = { showInfo = false }) { Text("Anladım") } },
            title = { Text("Fırsat Avcısı") }, text = { Text("Bu ilk MVP sürümüdür. Favoriler cihazında saklanır. Bildirim izni test bildirimiyle doğrulanır. Gerçek BİM, ŞOK ve A101 kampanya akışı sonraki aşamada bağlanacaktır.") })
    }
}
@Composable
private fun DealCard(deal: Deal, favorite: Boolean, onFavorite: () -> Unit) {
    Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(2.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = RoundedCornerShape(14.dp), color = Color(0xFFEAF4ED), modifier = Modifier.size(58.dp)) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(deal.category.icon, null, tint = Color(0xFF167A45), modifier = Modifier.size(30.dp))
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(deal.market, style = MaterialTheme.typography.labelMedium, color = Color(0xFF167A45), fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(8.dp))
                    Text("-${deal.discount}%", style = MaterialTheme.typography.labelSmall, color = Color(0xFFB54708), fontWeight = FontWeight.Bold)
                }
                Text(deal.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(deal.category.title, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(String.format(Locale.forLanguageTag("tr-TR"), "%,.2f TL", deal.price), color = Color(0xFF167A45), fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(8.dp))
                    Text(String.format(Locale.forLanguageTag("tr-TR"), "%,.2f TL", deal.oldPrice), style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                }
            }
            IconButton(onClick = onFavorite) { Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Favoriye ekle", tint = if (favorite) Color.Red else Color.Gray) }
        }
    }
}
