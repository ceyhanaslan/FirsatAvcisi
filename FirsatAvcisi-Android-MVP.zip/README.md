# Fırsat Avcısı — Android MVP

Native Android app using Kotlin, Jetpack Compose and Material 3.

## Requirements
- Android Studio (current stable)
- JDK 17+
- Android SDK 35

## Open and build
1. Extract this ZIP.
2. Open the `FirsatAvcisi-Android` folder in Android Studio.
3. Allow Gradle sync and install any requested Android SDK components.
4. Connect an Android phone with USB debugging enabled, or use an emulator.
5. Press Run.

To create an APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
The debug APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.

## MVP included
- BİM / ŞOK / A101 market filters
- Ev ve yaşam / Spor ve fitness / Gıda category filters
- Product search and discount sorting
- Favorites saved locally
- Notification permission and a test notification
- Demo product data

## Important
The listed products and prices are sample/demo data, not verified current campaigns.
Real campaign ingestion, price history, server-side monitoring and push notifications require a backend and verified data sources. This starter does not scrape retailer websites.
